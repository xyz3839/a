package com.example.sign_up_page;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
